#runApp('/Users/cuatrooctavos/Dropbox/Web_agents')




#runApp('/Users/cuatrooctavos/Desktop/world_map')

library(shiny)
runApp('/Users/cuatrooctavos/Desktop/Introduction_1_2/Tribute_Model')


